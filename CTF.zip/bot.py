from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
import sys
import base64
path=base64.b64decode(sys.argv[1]).decode()
import time
import requests
chrome_options = Options()
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--headless")
chrome_options.add_argument("--disable-extensions")
chrome_options.add_argument("--disable-gpu")

#CHANGE THESE SETTINGS
#CHANGE THESE SETTINGS
def getAdminCookie():
    s=requests.Session()
    r=s.post('http://127.0.0.1/ctf/index.php',data={'username':'admin','password':'admin','login-submit':'Log In'},allow_redirects=True)    
    adminsess=s.cookies['PHPSESSID']
    print(adminsess)
    return adminsess
ctfhost = "127.0.0.1/ctf"
cookie = {"name":"PHPSESSID","domain":"127.0.0.1","value":getAdminCookie()}
ctfurl = "http://"+ctfhost+path
testUrl = "http://"+ctfhost + "/" # USED TO SET THE COOKIE BEFORE HITTING XSS PAGE
######################
print("Getting page")


print("Creating driver")
driver = webdriver.Chrome(ChromeDriverManager().install(), options=chrome_options)
print("Requesting testURL and settings cookies...")
print("Cookie Value:", cookie)
driver.get(testUrl)
driver.add_cookie(cookie)

try:
    for i in range(1): # Run same driver for max of 1000 requests
        print("Sending request to CTF Url", ctfurl)
        driver.get(ctfurl)
        alertCount = 0
        while True:
            try:
                alert = driver.switch_to.alert
                print(alert)
                alert.accept()
                alertCount+=1
                if alertCount > 10:
                    print("Alert loop, breaking loop") # if code is popping alerts time to kill the page
                    break
            except:
                break
        if alertCount > 10: # If there is an alert loop break out of for loop and close the driver and make a new instance
            print("Alert loop found, killing driver and starting fresh")
            break
        time.sleep(5)
        driver.quit()
except:
    print("Error_to_catch")


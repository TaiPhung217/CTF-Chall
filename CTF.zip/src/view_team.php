<?php

session_start();

require_once('db.php');
if(empty($_SESSION['name']))
{
die("Location:index.php");
}
if(!empty($_GET['id']))
{

$stmt = $conn->prepare("select * from teams where id=?");
$stmt->bind_param("s", $_GET['id']);
$stmt->execute();
$res=$stmt->get_result();
if($res->num_rows==1)
{
    $team=$res->fetch_assoc();
    $team_name=$team['name'];
    $stmt = $conn->prepare("select * from users where team=?");
    $stmt->bind_param("s", $team_name);
    $stmt->execute();
    $res=$stmt->get_result();
    
}
else
{
    die("error id ");
}
}
else
{
    die("error id ");
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Players</h1>
    <?php while($users=$res->fetch_assoc()){
        echo "username: ".$users['username']."<br/>";
    }
        ?>
</body>
</html>
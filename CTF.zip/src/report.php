<?php


if(isset($_POST['send']))
{
    if (!empty($_POST['path']))
    {
        $path=$_POST['path'];
        if(str_starts_with($path,'/profile.php?id=') )
        {
            $bot_res=exec("python3 /bot.py '".base64_encode($path)."'");
            if(preg_match('/Error_to_catch/',$bot_res))
            {
                die("error");
            }
            else
            {
                echo "<script>alert('Bot visited ur link')</script>";
            }
        }
        else
        {
            die("it must starts with /uploads");
        }


    }
}

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report to admin</title>

</head>
<body>
    <form method="POST">
        <input name="path" placeholder="Enter your profile path start with /profile.php">
    <input type="submit" name="send" >
    </form>
</body>
</html>
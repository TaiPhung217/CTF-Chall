<?php

session_start();

require_once('db.php');

if(!empty($_SESSION['team']))
{
    die("<script>alert('You already joined team');history.back()</script>");
}

if(isset($_POST['submit']))
{
    if(!empty($_POST['name']) && !empty($_POST['secret']))
    {
        $name=htmlspecialchars($_POST['name']);
        $secret=htmlspecialchars($_POST['secret']);
        $stmt = $conn->prepare("select * from teams where name=?");
		$stmt->bind_param("s", $name);
		$stmt->execute();
        $res=$stmt->get_result();
        if($res->num_rows >0)
        {
            echo "Sorry team name already exist";
        }
        elseif(!is_numeric($secret))
        {
            echo "secret must be a number only";
        }
        else
        {
            $stmt = $conn->prepare("insert into teams(name,secret,leader)values(?,?,?)");
            $stmt->bind_param("sss", $name,$secret,$_SESSION['name']);
            $stmt2 = $conn->prepare("update users set team=? where uuid=?");
            $stmt2->bind_param("ss", $name,$_SESSION['uuid']);
            if($stmt->execute() && $stmt2->execute())
            {
                $_SESSION['team']=$name;
                $_SESSION['team_key']=$secret;
                echo "<Script>alert('Team added');history.back();</script>";
            }
            else
            {
                echo "error";
            }
        }
    }
    else
    {
        echo "please fill all fields";
    }
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Team</title>
</head>
<body>
    <form method="post">
        <label for="name">Team name</label>
        <input name="name"><br>
        <label for="secret">Team secret : (must be a number)</label>
        <input name="secret" type="password"><br>
        <input type="submit" name="submit">
    </form>
</body>
</html>
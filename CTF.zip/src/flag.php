<?php
session_start();
require_once('db.php');

if($_SESSION['team']=='admin')
{
    echo "0xL4ugh{CongratzZ_U_ExfilledData_and_reviewed_Js}";
}


?>
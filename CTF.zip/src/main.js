const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);

var usermajor = document.getElementById("user_major");
var userteam = document.getElementById("user_team");

fetch('../check.php')           
    .then(response => response.json())
    .then(data => {
        const major=data["major"];
        let team_name=data["team"];
        usermajor.innerHTML=major;
        team_name=team_name||"you didn't join yet";
        userteam.innerHTML="Team: "+team_name;
        addCssLink(getCssFile(urlParams.get("color")||major));
        
});


function addCssLink(e)
{
    var r = document.createElement('link');
    r.href = e,
    r.type = 'text/css',
    r.rel = 'stylesheet'
    var t = document.getElementsByTagName('head') [0],
    n = t.getElementsByTagName('style') [0];
  
    r.onload = function ()
    {
      var e = document.getElementById('loaders-style');
      e && t.removeChild(e)
    },
    n ? t.insertBefore(r, n) : t.appendChild(r)
}


function getCssFile(e)
{
  return '/ctf/style/team_' + e + '.css'; //edit this
}

function createTeam()
{
  window.location='../create_team.php';
}
function joinTeam()
{
  window.location='../join_team.php';
}



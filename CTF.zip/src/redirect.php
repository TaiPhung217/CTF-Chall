<?php

if(!empty($_GET['url']))
{
$url=$_GET['url'];
header("Location:$url");
}
?>
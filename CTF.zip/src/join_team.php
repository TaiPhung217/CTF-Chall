<?php

session_start();

require_once('db.php');

if(isset($_POST['submit']))
{
    if(!empty($_POST['secret'])&&!empty($_POST['name']))
    {
        $secret=$_POST['secret'];
        $stmt = $conn->prepare("select * from teams where secret=?");
		$stmt->bind_param("s", $secret);
		$stmt->execute();
        $res=$stmt->get_result();
        $team_data=$res->fetch_assoc();
        
        if($res->num_rows >0)
        {
            $team=$team_data['name'];
            $stmt = $conn->prepare("update users set team=? where uuid=?");
            $stmt->bind_param("ss", $team,$_SESSION['uuid']);
            if($stmt->execute())
            {
                $_SESSION['team']=$team;
                $_SESSION['team_key']=$secret;
                echo "<script>alert('You joined $team team');history.back();</script>";
            }
        }
        else
        {
            echo "Wrong team data";
        }
    }
    else
    {
        echo "please fill all fields";
    }
}

?>





<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join Team</title>
</head>
<body>
    <form method="post">
        <label for="name">Team name</label>
        <input name="name"><br>
        <label for="secret">Team secret : (must be a number)</label>
        <input name="secret" type="password"><br>
        <input type="submit" name="submit">
    </form>
</body>
</html>
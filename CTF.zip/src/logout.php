<?php

session_abort();
session_destroy();
setcookie("PHPSESSID",FALSE);


?>
<?php

session_start();

require_once('db.php');

if (!empty($_GET['id']))
{
    $id=$_GET['id'];
    $stmt1 = $conn->prepare("select * from users where uuid=?");
    $stmt1->bind_param("s", $id);
    $stmt1->execute();
    $res1=$stmt1->get_result();
    
    if($res1->num_rows !==1)
    {   
        die("Invalid ID");
    }
    elseif(@$_SESSION['uuid']!==$id)
    {
        die("Unauthorized");
    }
    else
    {
        $user=$res1->fetch_assoc();
        $team_name=$_SESSION['team'];
        $stmt2 = $conn->prepare("select * from teams where name=?");
        $stmt2->bind_param("s", $team_name);
        $stmt2->execute();
        $res2=$stmt2->get_result();
        $team=$res2->fetch_assoc();
    }
}
else
{
    header("Location:../index.php");
}



?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../style/bootstrap.min.css" rel="stylesheet">
    <link href="../style/font-awesome.min.css" rel="stylesheet">
    <title>Profile</title>
</head>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<style>
    body{
    background:#eee;
}

.card{
    border:none;

    position:relative;
    overflow:hidden;
    border-radius:8px;
    cursor:pointer;
}

.card:before{
    
    content:"";
    position:absolute;
    left:0;
    top:0;
    width:4px;
    height:100%;
    background-color:#E1BEE7;
    transform:scaleY(1);
    transition:all 0.5s;
    transform-origin: bottom
}

.card:after{
    
    content:"";
    position:absolute;
    left:0;
    top:0;
    width:4px;
    height:100%;
    background-color:#8E24AA;
    transform:scaleY(0);
    transition:all 0.5s;
    transform-origin: bottom
}

.card:hover::after{
    transform:scaleY(1);
}


.fonts{
    font-size:11px;
}

.social-list{
    display:flex;
    list-style:none;
    justify-content:center;
    padding:0;
}

.social-list li{
    padding:10px;
    color:#8E24AA;
    font-size:19px;
}


.buttons button:nth-child(1){
       border:1px solid #8E24AA !important;
       color:#8E24AA;
       height:40px;
}

.buttons button:nth-child(1):hover{
       border:1px solid #8E24AA !important;
       color:#fff;
       height:40px;
       background-color:#8E24AA;
}

.buttons button:nth-child(2){
       border:1px solid #8E24AA !important;
       background-color:#8E24AA;
       color:#fff;
        height:40px;
}
</style>
<body>
<div class="container mt-5">
    
    <div class="row d-flex justify-content-center">
        
        <div class="col-md-7">
            
            <div class="card p-3 py-4">
                
                <div class="text-center">
                    <img src="https://i.imgur.com/aCwpF7V.jpg" width="100" class="rounded-circle">
                </div>
                
                <div class="text-center mt-3">
                    <span class="bg-secondary p-1 px-4 rounded text-white" id="user_major"></span>
                    <h5 class="mt-2 mb-0">Username : <?=$user['username']?></h5>
                    
                    
                    <div class="px-4 mt-1">
                        <p id="user_team"></p>
                        <?php if(!empty($_SESSION['team_key'])){
                            echo  '<a href="../view_team.php?id='.$team['id'].'">Click here to view your team</a><br>';
                            echo '<input id="secret_key" type="hidden" value="'.$_SESSION['team_key'].'">';}?>
                        
                        <input id="create_team" type="submit" value="Create a new team" onclick="createTeam()">
                        <input id="join_team" type="submit" value="Join an existing team" onclick="joinTeam()">

                    </div>
                    <a href="logout.php">Logout</a>
                    
                </div>
                
            
                
                
            </div>
            
        </div>
        
    </div>
    
</div>
<script src="../main2.js"></script>

</body>
</html>
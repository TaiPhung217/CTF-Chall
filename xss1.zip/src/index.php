<?php
session_start();
ini_set("session.cookie_httponly", 1);
$session_id=$_COOKIE['PHPSESSID'];

if(!is_dir("uploads/$session_id"))
{
    mkdir("uploads/$session_id");
}

if(isset($_POST['submit']))
{
    if(!empty($_FILES["fileToUpload"]["name"]))
    {
        $file_name=basename($_FILES["fileToUpload"]["name"]);
        if(str_ends_with($file_name,'.jpg') || str_ends_with($file_name,'.jpeg') || str_ends_with($file_name,'.png'))
        {
            $target_file="uploads/$session_id/".basename($_FILES["fileToUpload"]["name"]);
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file))
            {
                echo "The file ". htmlspecialchars($target_file). " has been uploaded.";
            }
        }
        else
        {
            echo "Not allowed ";
        }
    }
    else
    {
        echo "Please Fill All Fields";
    }
}
?>




<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xss2 Challenge</title>
</head>
<body>
    <form  method="post" enctype="multipart/form-data">
        Select image to upload (png and jpg and jpeg photos are allowed only) <br>
        <input type="file" name="fileToUpload" id="fileToUpload">
        <input type="submit" value="Upload Image" name="submit">
    </form>
</body>
</html>